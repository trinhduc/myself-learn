*IDF Importer WorkBench* for FreeCAD v3.9:
 correctly importing of kicad IDF board and parts

main improvements
- removing step search associations (too old models)
- displaying Flat Mode models
- supporting Z position
- skipping PROP in emp file
- adding color to shapes opt IDF_colorize
- adding emp library/single model load support
- aligning IDF shape to both Geom and PartNBR

  to install the IDFImporter follow these instructions
  http://www.freecadweb.org/wiki/index.php?title=Installing_more_workbenches
  
  in IDFImporter folder README.txt and some pngs of the kicad pic_programmer
  demo board exported to IDF

  
#*   This program is free software; you can redistribute it and/or modify  *
#*   it under the terms of the GNU Library General Public License (LGPL)   *
#*   as published by the Free Software Foundation; either version 2 of     *
#*   the License, or (at your option) any later version.                   *
#*   for detail see the LICENCE text file.                                 *
  