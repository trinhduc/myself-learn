A script to check for annular ring violations
both for pads and vias 
4 KiCAD pcbnew

execfile("annular.py")
annular.py Testing PCB for Annular Ring >= 0.15

## todo
- add colors to print
